from braket.circuits import Circuit
from braket.aws import AwsDevice
import boto3
import time
import uuid

def get_or_create_braket_bucket():
    """
    Checks for an existing custom q-sentinel tracking bucket that matches AWS rules.
    If none exists, builds a valid, globally unique bucket starting with 'amazon-braket-'.
    """
    s3_client = boto3.client('s3', region_name='us-west-1')
    
    # 1. Check if a bucket starting with our specific pattern already exists
    try:
        response = s3_client.list_buckets()
        for bucket in response.get('Buckets', []):
            name = bucket['Name']
            if name.startswith("amazon-braket-q-sentinel-"):
                return name
    except Exception as e:
        print(f"[!] Warning inspecting bucket metadata: {e}")

    # 2. If none matches, generate a unique ID using the mandatory 'amazon-braket-' prefix
    unique_id = uuid.uuid4().hex[:12]
    new_bucket_name = f"amazon-braket-q-sentinel-{unique_id}"
    
    print(f"[+] Instantiating mandatory AWS S3 tracking bucket: {new_bucket_name}")
    try:
        s3_client.create_bucket(
            Bucket=new_bucket_name,
            CreateBucketConfiguration={'LocationConstraint': 'us-west-1'}
        )
        time.sleep(2)  # Give S3 context propagation a brief rest window
        return new_bucket_name
    except Exception as e:
        print(f"[X] Failed to auto-create destination bucket: {e}")
        raise e

def run_simons_audit(data_points, simulator_type="SV1"):
    """
    Executes Simon's Algorithm matrix map over the ingested target arrays.
    """
    n = 4 
    circuit = Circuit().h(range(n))
    
    for i in range(n):
        circuit.cnot(i, i + n)
    circuit.h(range(n))

    # Pull or establish our valid target logging directory
    assigned_bucket = get_or_create_braket_bucket()
    s3_target = (assigned_bucket, "tasks")

    if simulator_type == "SV1":
        device = AwsDevice("arn:aws:braket:::device/quantum-simulator/amazon/sv1")
        print(f"[!] Submitting workload to SV1 Simulator (100 shots)...")
        task = device.run(circuit, s3_destination_folder=s3_target, shots=100)
    
    elif simulator_type == "Cepheus":
        cepheus_arn = "arn:aws:braket:us-west-1::device/qpu/rigetti/Cepheus-1-108Q"
        device = AwsDevice(cepheus_arn)
        print(f"[!] Cepheus-1-108Q Status: {device.status}")
        print(f"[!] Submitting task to Rigetti Cepheus-1 QPU (100 shots)...")
        task = device.run(circuit, s3_destination_folder=s3_target, shots=100)
    else:
        return "0000"

    # Await response lifecycle return status 
    while task.state() not in ["COMPLETED", "FAILED", "CANCELLED"]:
        time.sleep(0.5)
        
    if task.state() == "COMPLETED":
        results = task.result()
        counts = results.measurement_counts
        most_common_pattern = max(counts, key=counts.get)
        return most_common_pattern[:4]
    else:
        print(f"[X] Quantum calculation dropped with status state: {task.state()}")
        return "0000"

def get_rigetti_telemetry():
    """
    Fetches hardware state profiles for the Rigetti Cepheus-1 hardware suite.
    """
    cepheus_arn = "arn:aws:braket:us-west-1::device/qpu/rigetti/Cepheus-1-108Q"
    try:
        device = AwsDevice(cepheus_arn)
        status = device.status
        is_available = device.is_available
        props = device.properties.dict()
        last_update = device.properties.service.updatedAt
        temp = props.get('provider', {}).get('specs', {}).get('fridge_temperature', "N/A")

        print("\n" + "="*45)
        print("   RIGETTI CEPHEUS-1 QPU TELEMETRY")
        print("="*45)
        print(f"DEVICE STATUS:   {status}")
        print(f"AVAILABILITY:    {'READY/ONLINE' if is_available else 'BUSY/OFFLINE'}")
        print(f"TEMPERATURE:     {temp} mK")
        print(f"LAST CAL CYCLE:  {last_update}")
        print("="*45)
    except Exception as e:
        print("\n[X] Unable to pull live AWS telemetry profiles.")
        print(f"[ERROR] {e}")
        