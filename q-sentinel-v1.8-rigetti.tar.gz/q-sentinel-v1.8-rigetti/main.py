import questionary
import os
import sys
import json
import hashlib
from datetime import datetime
from collections import Counter
from log_parser import extract_all_unauthorized_attempts, extract_aapanel_access_data
from quantum_processor import run_simons_audit, get_rigetti_telemetry

DB_FILE = "completed_tasks.json"

def save_to_ledger(log_file, backend, signature, label, data_points):
    """Saves telemetry analysis structures down to local tracking database ledger."""
    counts = Counter(data_points)
    total = len(data_points)
    detailed_results = [{"identity": i, "percentage": f"{(c/total)*100:.2f}%", "count": c} for i, c in counts.most_common(10)]
    timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    task_hash = hashlib.md5(f"{timestamp_str}{log_file}".encode()).hexdigest()[:8].upper()
    
    new_entry = {
        "task_id": f"QS-{task_hash}",
        "timestamp": timestamp_str,
        "target_file": log_file,
        "category": label,
        "qpu_backend": backend,
        "quantum_signature": signature,
        "detailed_findings": detailed_results
    }
    
    data = []
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r') as f:
                data = json.load(f)
        except json.JSONDecodeError:
            data = []
            
    data.append(new_entry)
    with open(DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def main():
    print("\n====================================================")
    print("   Q-SENTINEL: COST-EFFICIENT QPU AUDIT (v1.8.1)   ")
    print("====================================================")
    print("REQUIREMENT: AWS CLI MUST BE SET TO 'us-west-1'")
    
    choice = questionary.select(
        "Select Action:",
        choices=["0. QPU Telemetry", "1. SV1 Simulator", "2. Cepheus-1 QPU", "Exit"]
    ).ask()

    if choice == "Exit" or not choice:
        sys.exit(0)

    if "0." in choice:
        get_rigetti_telemetry()
        input("\nEnter...")
        main()
        return

    backend = "Cepheus" if "2." in choice else "SV1"
    audit_type = questionary.select("Category:", choices=["1. SSH (auth.log)", "2. aaPanel (access.log)", "Back"]).ask()
    if "Back" in audit_type or not audit_type:
        main()
        return

    selected_log = "auth.log" if "1." in audit_type else "access.log"

    print(f"\n[!] Parsing local directory file context ({selected_log}) for {backend} distribution...")
    
    if "1." in audit_type:
        data_points = extract_all_unauthorized_attempts(selected_log)
    else:
        data_points = extract_aapanel_access_data(selected_log)
    
    if not data_points:
        print("[X] Execution halted due to empty data context structure.")
        input("\nEnter..."); main(); return

    sig = run_simons_audit(data_points, simulator_type=backend)
    
    counts = Counter(data_points)
    total = len(data_points)
    print("\n" + "="*65)
    print(f"{'IDENTIFIED PATTERN':<35} | {'ATTEMPT %':<15}")
    print("-" * 65)
    for item, count in counts.most_common(10):
        pct = (count / total) * 100
        print(f"{item:<35} | {pct:.2f}% ({count} entries)")
    print("-" * 65)
    print(f"QUANTUM SIGNATURE PATTERN INTERCEPTED: {sig}")
    print("="*65)

    save_to_ledger(selected_log, backend, sig, "THREAT", data_points)
    print("[OK] Session results saved into completed_tasks.json ledger.")
    input("\nEnter...")
    main()

if __name__ == "__main__":
    main()
    