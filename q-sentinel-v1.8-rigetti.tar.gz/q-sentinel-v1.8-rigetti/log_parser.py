import re
import os

def extract_all_unauthorized_attempts(file_path="auth.log"):
    """
    Parses an unprivileged auth.log copy sitting directly in the project directory
    for unauthorized SSH identity strings.
    """
    all_names = []
    
    # Force the target to look strictly in the current working directory
    target = os.path.basename(file_path) if file_path else "auth.log"
    
    pattern = re.compile(r"(?:Invalid user|Failed password for(?: invalid user)?) ([^\s]+) from")
    
    try:
        with open(target, 'r') as f:
            for line in f:
                match = pattern.search(line)
                if match:
                    all_names.append(match.group(1).strip())
    except FileNotFoundError:
        print(f"\n[X] Error: '{target}' was not found in this folder!")
        print("    Please place a copy of the log file directly next to main.py.")
        return None
    except PermissionError as e:
        print(f"\n[X] Error: Unable to read local file due to OS permissions: {e}")
        return None
        
    return all_names

def extract_aapanel_access_data(file_path="access.log"):
    """
    Parses a local access.log copy in the project directory for web scanning traces.
    """
    access_signatures = []
    target = os.path.basename(file_path) if file_path else "access.log"

    pattern = re.compile(r'(\d+\.\d+\.\d+\.\d+) - - .*?"\w+ (.*?) HTTP/.*?" (\d+)')
    
    try:
        with open(target, 'r') as f:
            for line in f:
                match = pattern.search(line)
                if match:
                    ip, path, status = match.groups()
                    if status.startswith('4'):
                        access_signatures.append(ip)
    except FileNotFoundError:
        print(f"\n[X] Error: '{target}' was not found in this folder!")
        print("    Please place a copy of the log file directly next to main.py.")
        return None
    except PermissionError as e:
        print(f"\n[X] Error: Unable to read local file due to OS permissions: {e}")
        return None
        
    return access_signatures
    